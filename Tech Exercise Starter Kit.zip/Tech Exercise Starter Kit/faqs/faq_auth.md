# Auth FAQ

Q: How do I reset my password?
A: Use the reset link on the login page.
