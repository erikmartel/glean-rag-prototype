# TechFlow Solutions Employee Handbook

## What is our unlimited PTO policy?
TechFlow offers unlimited PTO with a minimum requirement of 15 days per year. Employees must get approval for time off exceeding 2 consecutive weeks. PTO requests require 2-week notice except for emergencies.

## How does our equity vesting schedule work?
New hires receive equity grants vesting over 5 years: 10% after year 1, then 22.5% each subsequent year. Equity grants are reviewed annually in March with potential for additional grants based on performance.
