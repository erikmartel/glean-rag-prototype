# SSO FAQ

Q: How do I enable SSO?
A: Contact your admin to enable SSO for your account.
